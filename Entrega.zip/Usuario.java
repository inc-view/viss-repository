package projetoIndividual;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Usuario {

    Scanner leitor = new Scanner(System.in);
    List<String> usuario = new ArrayList();
    List<String> email = new ArrayList();
    List<String> senha = new ArrayList();
    List<String> status = new ArrayList();
    List<Double> cpu = new ArrayList();
    List<Double> ram = new ArrayList();
    List<Double> disco = new ArrayList();

    Integer escolha;
    Integer posicao;

    Double estresse = 0.0;
    String comparadorEmail = "";
    String comparadorSenha = "";
    String bugInt = "";
    Boolean checkEmail = false;
    Boolean checkSenha = false;

    String stringAzul = "\u001B[34m";
    String stringReset = "\u001B[0m";

    public void setEntrar() {

        System.out.println( stringAzul +"""
                ######  ##   ##    ####                     ##   ##   ######   ######  ##   ## \s
                # ## #  ###  ##   ##  ##                    ##   ##   # ## #   ##      ##   ## \s
                  ##    #### ##  ##                         ##   ##     ##     ##      ## # ## \s
                  ##    #######  ##                         ### ###     ##     #####   ####### \s
                  ##    ## ####  ##                          #####      ##     ##      ####### \s
                # ## #  ##  ###   ##  ##     ##               ###     # ## #   ##       ## ##  \s
                ######  ##   ##    ####      ##                #      ######   ######   #   #  \s
                                              """ + stringReset);


        System.out.println("Bem vindo ao sistema de monitoramento da Inc.View!");
        System.out.println("\nEscolha uma opção\n[1]Entrar\n[0]Sair");
        escolha = leitor.nextInt();
        if (escolha == 1){
            bugInt = leitor.nextLine();
            login();
        }else {
            System.out.println("Até Logo!");
        }
    }
    void login() {
        System.out.println("Informe seu email:");
        comparadorEmail = leitor.nextLine();
        System.out.println("Informe sua senha:");
        comparadorSenha = leitor.nextLine();

        for (int i = 0; i < email.size() ; i++) {
            if (comparadorEmail.equals(email.get(i))) {
                posicao = i;
                checkEmail = true;
            }
        }
        if (checkEmail){
            if (comparadorSenha.equals(senha.get(posicao))) {
                checkSenha = true;
            }
        }

        if (checkEmail && checkSenha) {
            System.out.printf("Bem vindo %s" , usuario.get(posicao));
            boasvindas();
        } else {
            System.out.println("Email ou senha incorreto!");
            senhaIncorreta();
        }
    }

    void senhaIncorreta() {
        System.out.println("\nEscolha uma opção\n[1]Tentar Novamente\n[0]Sair");
        escolha = leitor.nextInt();
        bugInt = leitor.nextLine();
        if (escolha == 1){
            login();
        }else {
            System.out.println("Até Logo!");
        }
    }


    void boasvindas() {
        System.out.println("""
                              
                Escolha uma opção:
                    
                [1] Informações da conta
                [2] Visualizar Maquinas
                [0] Sair
                """);
        escolha = leitor.nextInt();
        bugInt = leitor.nextLine();

        if (escolha == 1){
            informacoes();
        }else if (escolha == 2){
            visualizar();
        } else {
            System.out.println("Até Logo!");
        }


    }

    void informacoes() {
        System.out.printf("""
                Nome: %s
                Email: %s
                Senha: %s
                """ , usuario.get(posicao) , email.get(posicao) , senha.get(posicao));

        System.out.println("\nEscolha uma opção\n[1]Voltar\n[0]Sair");
        escolha = leitor.nextInt();
        if (escolha == 1){
            boasvindas();
        }else {
            System.out.println("Até Logo!");
        }
    }

    void visualizar() {
        System.out.printf("""
                Usuario | Status | CPU | Ram | Disco |
                """);
        for (int i = 0; i < usuario.size(); i++) {
            System.out.printf("""
                    %s | %s | %.2f%% | %.2f%% | %.2f%% |
                    """ , usuario.get(i) , status.get(i) , cpu.get(i) , ram.get(i) , disco.get(i));
        }

        System.out.println("\nEscolha uma opção\n[1]Voltar\n[2]Simular Estresse\n[0]Sair");
        escolha = leitor.nextInt();
        if (escolha == 1){
            boasvindas();
        } else if (escolha == 2) {
            simularEstresse();
        } else {
            System.out.println("Até Logo!");
        }
    }
    void simularEstresse() {

        estresse = (Math.random() + 1);

        System.out.printf("Simulando estresse em %.2f vezes" , estresse);
        System.out.printf("""
                
                Usuario | Status | CPU | Ram | Disco |
                """);
        for (int i = 0; i < usuario.size(); i++) {
            System.out.printf("""
                    %s | %s | %.2f%% | %.2f%% | %.2f%% |
                    """ , usuario.get(i)  , status.get(i) , cpu.get(i) * estresse , ram.get(i) * estresse , disco.get(i) * estresse);
        }

        System.out.println("\nEscolha uma opção\n[1]Voltar\n[0]Sair");
        escolha = leitor.nextInt();
        if (escolha == 1){
            boasvindas();
        }else {
            System.out.println("Até Logo!");
        }
    }


}

