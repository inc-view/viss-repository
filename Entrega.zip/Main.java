package projetoIndividual;

public class Main {
    public static void main(String[] args) {
            Usuario dados = new Usuario();

        dados.usuario.add("Nicolas");
        dados.usuario.add("Gabriel");
        dados.usuario.add("João");
        dados.usuario.add("Lucas");
        dados.usuario.add("Mario");
        dados.usuario.add("Bernardo");

        dados.email.add("nicopz2005@gmail.com");
        dados.email.add("gabriel@gmail.com");
        dados.email.add("joao@gmail.com");
        dados.email.add("lucas@gmail.com");
        dados.email.add("mario@gmail.com");
        dados.email.add("bernardo@gmail.com");

        dados.senha.add("nicolas123456");
        dados.senha.add("gariel123456");
        dados.senha.add("joao123456");
        dados.senha.add("lucas123456");
        dados.senha.add("mario123456");
        dados.senha.add("bernardo123456");

        dados.status.add("Online ");
        dados.status.add("Online ");
        dados.status.add("OffLine");
        dados.status.add("Online ");
        dados.status.add("Offline");
        dados.status.add("Online ");

        dados.cpu.add(44.0);
        dados.cpu.add(20.0);
        dados.cpu.add(0.0);
        dados.cpu.add(40.0);
        dados.cpu.add(0.0);
        dados.cpu.add(35.0);

        dados.ram.add(30.0);
        dados.ram.add(15.0);
        dados.ram.add(0.0);
        dados.ram.add(49.0);
        dados.ram.add(0.0);
        dados.ram.add(34.0);

        dados.disco.add(32.0);
        dados.disco.add(23.0);
        dados.disco.add(0.0);
        dados.disco.add(30.0);
        dados.disco.add(0.0);
        dados.disco.add(26.0);

        dados.setEntrar();

        }
    }
